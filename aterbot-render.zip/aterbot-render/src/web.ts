import HTTP from 'node:http';

const PORT = process.env.PORT || 10000;
const server = HTTP.createServer((request, response) => {
	response.writeHead(200, {
		"Access-Control-Allow-Origin": "*",
		"Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
		"Content-Type": "text/html"
	} as const);
	response.end(`
		<!DOCTYPE html>
		<html>
		<head>
			<title>AterBot Status</title>
			<meta charset="utf-8">
			<style>
				body { 
					font-family: Arial, sans-serif; 
					display: flex; 
					justify-content: center; 
					align-items: center; 
					height: 100vh; 
					margin: 0; 
					background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
					color: white;
				}
				.container { text-align: center; }
				h1 { font-size: 3em; margin: 0; }
				p { font-size: 1.5em; }
				.status { 
					display: inline-block; 
					width: 20px; 
					height: 20px; 
					border-radius: 50%; 
					background: #00ff00; 
					animation: pulse 2s infinite;
					margin-right: 10px;
				}
				@keyframes pulse {
					0% { box-shadow: 0 0 0 0 rgba(0, 255, 0, 0.7); }
					70% { box-shadow: 0 0 0 10px rgba(0, 255, 0, 0); }
					100% { box-shadow: 0 0 0 0 rgba(0, 255, 0, 0); }
				}
			</style>
		</head>
		<body>
			<div class="container">
				<h1>🤖 AterBot</h1>
				<p><span class="status"></span>Bot läuft 24/7!</p>
				<p style="font-size: 1em; opacity: 0.8;">Dein Aternos Server bleibt online ✨</p>
			</div>
		</body>
		</html>
	`);
});



export default (): void => {
	server.listen(PORT, () => console.log(`Server läuft auf Port ${PORT} - Bot ist online!`));
};