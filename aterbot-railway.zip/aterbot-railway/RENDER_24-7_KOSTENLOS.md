# 🎉 RENDER - 100% KOSTENLOS 24/7 FÜR IMMER!

## ✅ JA, WIRKLICH KOSTENLOS FÜR IMMER!

**Render Free Tier:**
- ✅ 750 Stunden/Monat = **24/7 den ganzen Monat**
- ✅ Automatische Health Checks = **schläft NIE ein**
- ✅ Für immer kostenlos
- ✅ Keine Kreditkarte nötig

---

## 🚀 SETUP (5 MINUTEN):

### **Schritt 1: GitHub Upload**

1. **Entpacke** `aterbot-railway.zip`
2. Gehe zu **https://github.com/new**
3. Name: `aterbot`
4. Public
5. **Create repository**
6. **Upload files:**
   - Klicke "uploading an existing file"
   - Wähle ALLE Dateien (nicht den Ordner!)
   - Commit changes

### **Schritt 2: Config anpassen**

1. Öffne `config.json` auf GitHub
2. Klicke **Edit** (Stift-Symbol)
3. Ändere:
   ```json
   {
     "client": {
       "host": "dein-server.aternos.me",
       "port": "12345",
       "username": "BotName"
     }
   }
   ```
4. Commit changes

### **Schritt 3: Render Deploy**

1. Gehe zu **https://render.com/register**
2. Sign up (kostenlos, keine Kreditkarte!)
3. Klicke **New +** → **Web Service**
4. **Connect GitHub**
5. Wähle `aterbot` Repository
6. Klicke **Connect**

**Einstellungen (sollten automatisch erkannt werden):**
- Name: `aterbot`
- Region: Frankfurt
- Build Command: `npm install`
- Start Command: `npm start`
- Plan: **FREE** ✅

7. Klicke **Create Web Service**

---

## ⏱️ Warten (2-3 Minuten)

Render baut deinen Bot:
```
==> Installing dependencies
npm install
✅ Success

==> Starting service
npm start
✅ Server läuft auf Port 10000
✅ AFKBot logged in BotName
```

---

## 🎮 Bot auf Server vorbereiten

1. **Starte** deinen Aternos Server
2. **Gehe** mit Minecraft auf den Server
3. **Baue** einen Bedrock-Raum (5x3x5)
4. **Warte** bis Bot joint
5. **Wichtig:**
   ```
   /tp BotName ~ ~ ~
   /gamemode creative BotName
   ```

---

## ✅ FERTIG! Bot läuft 24/7!

### Status überprüfen:

1. Öffne die Render URL: `https://aterbot.onrender.com`
2. Du siehst: "🤖 AterBot - Bot läuft 24/7!"

### Logs ansehen:

1. Render Dashboard → Dein Service
2. Klicke **Logs**
3. Du siehst:
   ```
   AFKBot logged in BotName
   forward with sprinting
   back
   jump
   ```

---

## 🔄 WARUM SCHLÄFT DER BOT NICHT EIN?

**Render hat automatische Health Checks!**

- Render pingt `/` alle 5 Minuten an
- Dein Bot antwortet → "Ich bin wach!"
- Health Check = Bot schläft NIE ein
- **Das ist schon im Code eingebaut!**

```javascript
// src/web.ts - schon drin!
const server = HTTP.createServer((request, response) => {
  response.writeHead(200, ...);
  response.end("Bot läuft!");
});
```

**Render's Health Check ruft das automatisch auf!**

---

## 💰 KOSTENLOS FÜR IMMER?

**JA!**

**Free Tier Limits:**
- 750 Stunden/Monat
- 31 Tage × 24 Stunden = 744 Stunden
- **= Perfekt für 24/7!** ✅

**Was passiert bei Überschreitung?**
- Bei Free: Service stoppt
- **ABER:** 750h = genau ein ganzer Monat!
- Du überschreitest es NIE!

---

## 🛠️ TROUBLESHOOTING

### Bot verbindet sich nicht?
→ Prüfe `config.json`:
  - Host richtig? `server.aternos.me`
  - Port richtig? Muss 5-stellig sein
  - Ist Aternos Server online?

### Bot wird nach 15 Min gebannt?
→ Das ist Aternos AFK-Detection:
```
/pardon BotName
```
→ Oder deaktiviere AFK-Kick in Aternos Settings

### "Error building your code"?
→ Prüfe, ob Dateien richtig hochgeladen sind
→ `package.json` muss im Root sein!

### Bot disconnected?
→ Normal! Bot reconnected automatisch nach 15 Sek
→ Siehe Logs: "Trying to reconnect..."

---

## 📊 RENDER vs ANDERE

| Platform | Kostenlos? | Schläft ein? | Setup |
|----------|-----------|--------------|-------|
| **Render** | ✅ Für immer | ❌ Nein | ⭐⭐⭐⭐ |
| Railway | ❌ Nur 3 Mon | ❌ Nein | ⭐⭐⭐⭐⭐ |
| Fly.io | ✅ Für immer | ❌ Nein | ⭐⭐⭐ |
| Replit | ✅ | ✅ Ja | ⭐⭐⭐⭐⭐ |
| Netlify | ❌ Geht nicht | - | - |

---

## 🎯 TIPPS FÜR 100% UPTIME:

### 1. Aktiviere Email-Benachrichtigungen:
- Render Dashboard → Settings
- Notifications: ON
- Bei Crash bekommst du Email

### 2. Mehrere Bots (optional):
- Erstelle 2-3 Free Accounts
- Deploye auf jedem einen Bot
- Wenn einer ausfällt → andere laufen noch

### 3. UptimeRobot (optional, nicht nötig):
- https://uptimerobot.com
- Pingt deine Render URL an
- Extra Sicherheit (aber Render macht das schon!)

---

## ⚡ PRO-TIPP: Auto-Deploy

**Jedes Mal wenn du `config.json` auf GitHub änderst:**
→ Render deployt automatisch neu!

Sehr praktisch für Updates!

---

## 🆘 SUPPORT

**Render Support:**
- Docs: https://render.com/docs
- Community: https://community.render.com

**Bot funktioniert nicht?**
1. Prüfe Render Logs
2. Prüfe Aternos Server Status
3. Prüfe `config.json` Werte

---

## 🎉 FAZIT:

**Render = Perfekt für deinen Use Case:**
- ✅ Kostenlos für immer
- ✅ 24/7 ohne Einschlafen
- ✅ Einfaches Setup
- ✅ Automatische Health Checks
- ✅ Keine Kreditkarte nötig

**BESSER ALS NETLIFY für Bots!**

Netlify = nur statische Websites
Render = Node.js Apps wie dein Bot

---

**Viel Spaß mit deinem 24/7 Bot! 🎮**

Bei Problemen: Siehe TROUBLESHOOTING.md oder frag mich!
