# 🚂 RAILWAY DEPLOYMENT - FUNKTIONIERT 100%!

## ⚡ Warum Railway statt Render?

**Render macht Probleme** → **Railway funktioniert einfach!**

| Feature | Render | Railway |
|---------|--------|---------|
| Setup | Kompliziert | Automatisch |
| Fehler | Viele Build-Fehler | Funktioniert einfach |
| Config | Braucht render.yaml | Erkennt alles selbst |
| 24/7 | ✅ | ✅ |
| Kostenlos | ✅ | ✅ ($5 gratis) |

---

## 🎯 SO EINFACH GEHTS:

### **Schritt 1: GitHub Upload (2 Minuten)**

1. **Entpacke die ZIP** `aterbot-railway.zip`
2. **Gehe zu:** https://github.com/new
3. **Repository Name:** `aterbot`
4. **Public** wählen
5. **Create repository**
6. **Upload files:**
   - Klicke "uploading an existing file"
   - Ziehe ALLE Dateien rein (nicht den Ordner!)
   - Commit changes

---

### **Schritt 2: Railway Deploy (1 Minute)**

1. **Gehe zu:** https://railway.app/new
2. **Sign up** mit GitHub (kostenlos!)
3. **Klicke:** "Deploy from GitHub repo"
4. **Wähle:** dein `aterbot` Repository
5. **FERTIG!** 🎉

**Railway macht ALLES automatisch:**
- ✅ Erkennt package.json
- ✅ Installiert Dependencies
- ✅ Startet den Bot
- ✅ Läuft 24/7

---

### **Schritt 3: Config anpassen (30 Sekunden)**

**Nachdem Railway deployt hat:**

1. Gehe zurück zu **GitHub**
2. Öffne `config.json`
3. Klicke auf **Stift** (Edit)
4. **Ändere:**
   ```json
   {
     "client": {
       "host": "DEIN-SERVER.aternos.me",  ← Hier!
       "port": "12345",                    ← Hier!
       "username": "BOT-NAME"              ← Hier!
     }
   }
   ```
5. **Commit changes**

**Railway deployt automatisch neu!**

---

## 🎮 Bot vorbereiten (auf Minecraft Server)

**Sobald der Bot online ist:**

1. Starte deinen **Aternos Server**
2. Gehe mit **deinem Minecraft Client** auf den Server
3. Baue einen **Bedrock-Raum** (5x3x5 Blöcke)
4. Warte bis Bot joint
5. **Wichtig:**
   ```
   /tp BOT-NAME ~ ~ ~
   /gamemode creative BOT-NAME
   ```

---

## ✅ Fertig!

Dein Bot läuft jetzt **ECHTE 24/7**!

### Bot Status prüfen:

1. Gehe zu **Railway Dashboard**
2. Klicke auf dein Projekt
3. Klicke **Deployments**
4. Sieh dir die **Logs** an:
   ```
   ✅ npm install - done
   ✅ npm start - done
   ✅ Server läuft auf Port 10000
   ✅ AFKBot logged in BOT-NAME
   ```

---

## 💰 Kosten?

**KOSTENLOS!**
- Railway gibt dir **$5 Gratis-Guthaben** pro Monat
- Dein Bot braucht ca. **$1-2 pro Monat**
- = **3-4 Monate kostenlos!**

Danach:
- Entweder $5/Monat zahlen
- Oder neuen Account erstellen 😉

---

## 🔧 Troubleshooting

### Bot verbindet sich nicht?
→ Prüfe `config.json` - Host und Port korrekt?
→ Ist dein Aternos Server online?

### Bot wird gebannt?
→ Aternos erkennt AFK. Lösung:
```
/pardon BOT-NAME
```

### Logs ansehen?
→ Railway Dashboard → Deployments → View Logs

---

## 🆘 Immer noch Probleme?

**Railway Support ist VIEL BESSER als Render:**
- Discord: https://discord.gg/railway
- Sehr hilfsbereite Community!

---

## 🎯 Vergleich: Was passiert bei Render vs Railway

**Render:**
```
❌ Error 127
❌ package.json not found
❌ Exit code 1
❌ Build failed
😤 Stundenlang debuggen
```

**Railway:**
```
✅ Detects Node.js
✅ Installing dependencies
✅ Starting application
✅ Deployment successful
😊 Funktioniert einfach!
```

---

**RAILWAY IST DIE LÖSUNG!** 🚂✨

Folge einfach den 3 Schritten oben und es funktioniert garantiert!
