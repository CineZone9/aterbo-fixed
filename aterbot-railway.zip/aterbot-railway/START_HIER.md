# 🚀 SO LÄDST DU ES RICHTIG AUF GITHUB HOCH!

## ⚠️ WICHTIG - Lies das zuerst!

Der Fehler `package.json not found` kommt, weil die Dateien in der falschen Ordnerstruktur sind!

---

## ✅ Richtige Upload-Methode:

### **Schritt 1: Entpacke die ZIP**
- Entpacke `aterbot-deploy-KORREKT.zip`
- Du siehst einen Ordner mit allen Dateien

### **Schritt 2: GitHub Repository erstellen**
1. Gehe zu https://github.com/new
2. Name: `aterbot` (oder beliebig)
3. Wähle **Public**
4. ✅ **NICHT** "Add a README file" anklicken!
5. Klicke **Create repository**

### **Schritt 3: Dateien hochladen - RICHTIG!**

**Option A: Drag & Drop (Einfachste Methode)**

1. Öffne den entpackten Ordner auf deinem Computer
2. **Wähle ALLE Dateien darin aus** (Strg+A / Cmd+A)
   ```
   ✅ package.json
   ✅ config.json
   ✅ render.yaml
   ✅ src/ (Ordner)
   ✅ README.md
   ✅ usw...
   ```
3. **Ziehe alle Dateien** in das GitHub Upload-Fenster
4. **NICHT den ganzen Ordner ziehen!** Nur den Inhalt!
5. Klicke **Commit changes**

**Das Ergebnis auf GitHub sollte so aussehen:**
```
dein-repo/
├── 📄 package.json          ← Direkt im Root!
├── 📄 config.json
├── 📄 render.yaml
├── 📁 src/
│   ├── index.ts
│   ├── bot.ts
│   └── web.ts
├── 📄 README.md
└── ...
```

**NICHT so:**
```
❌ FALSCH!
dein-repo/
└── 📁 aterbot-deploy-correct/    ← EXTRA Ordner!
    ├── package.json
    ├── config.json
    └── ...
```

---

**Option B: GitHub Desktop (falls installiert)**

1. Öffne GitHub Desktop
2. File → New Repository
3. Wähle den **Inhalt** des entpackten Ordners (nicht den Ordner selbst!)
4. Publish

---

**Option C: Git Command Line (für Profis)**

```bash
cd /pfad/zum/entpackten/ordner
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/DEIN-USERNAME/aterbot.git
git push -u origin main
```

---

## 🔧 Schritt 4: Config anpassen

**Bearbeite `config.json` auf GitHub:**

1. Klicke auf `config.json`
2. Klicke auf das Stift-Symbol (Edit)
3. Ändere:
   ```json
   {
     "client": {
       "host": "DEIN-SERVER.aternos.me",
       "port": "12345",
       "username": "DEIN-BOT-NAME"
     }
   }
   ```
4. Commit changes

---

## 🚀 Schritt 5: Auf Render deployen

1. https://render.com → Dashboard
2. **New +** → **Web Service**
3. Connect GitHub (falls noch nicht)
4. Wähle dein `aterbot` Repository
5. Klicke **Connect**

**Einstellungen (sollten automatisch erkannt werden):**
- ✅ **Build Command:** `npm install`
- ✅ **Start Command:** `npm start`
- ✅ **Plan:** Free

6. Klicke **Create Web Service**

---

## ✅ Fertig!

Nach 2-3 Minuten sollte der Bot laufen!

**Prüfe die Logs:**
```
==> Installing dependencies
npm install
added 50 packages

==> Starting service
npm start
Server läuft auf Port 10000 - Bot ist online!
AFKBot logged in BOT-NAME
```

---

## 🆘 Immer noch Fehler?

Siehe `WICHTIG_PACKAGE_JSON_FEHLER.md` für weitere Lösungen!

**Oder probiere Railway.app** - oft einfacher:
https://railway.app → New Project → Deploy from GitHub → Fertig!

---

**Viel Erfolg! 🎮**
